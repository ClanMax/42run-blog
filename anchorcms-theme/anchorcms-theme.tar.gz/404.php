<?php theme_include('header'); ?>
    
    <div class="page-wrap">
   <div class="main-aside">
        <main class="left-column">
        <div class="post">
           <p>К сожалению, страницы <code>/<?php echo htmlspecialchars(current_url()); ?></code> не существует. Лучшим решением будет вернуться <a href="<?php echo base_url(); ?>">на главную</a></p>
        </div>
       </main>
    </div>
</div>

<?php theme_include('footer'); ?>
